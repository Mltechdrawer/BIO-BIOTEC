# Ficha P1 · Ph

**Estudio GEO:** [GSE58051](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE58051) · **Plataforma:** [GPL13620](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GPL13620).

**Condición:** pH 8, 6 min.

**Método de selección:** log2((intensidad RA normalizada t+1)/(intensidad RA normalizada t0+1)); fichero suplementario agregado; filtro max(intensidad)>=10; abs(log2 FC)>=1; no p diferencial.

**Genes en background:** 4760. **Genes seleccionados:** 872 (137 con cambio positivo, 735 negativo).

**Datos:** valores reales de las matrices publicadas en GEO, procesados para esta práctica. El umbral ±1 en escala log₂ equivale a una razón de 2, y se ha establecido como criterio docente **exploratorio**, no como significación de expresión diferencial.

**Precauciones:** no interpretar la magnitud de cambio como valor p; no inferir activación de procesos a partir del enriquecimiento; la normalización de datos y la calidad experimental no han sido reestimadas aquí. Los genes se deduplican por identificador sistemático ORF, representando varias sondas mediante la mediana de sus valores. El background contiene todos los genes elegibles según filtros de la misma condición.

**Herramienta de enriquecimiento:** utilizar listas .txt de IDs sistemáticos y definir explícitamente como background la lista del mismo código.

**Diseño:** la matriz suplementaria agregada tiene una columna RA por tiempo, sin tres réplicas separadas. No se estima significación diferencial.
