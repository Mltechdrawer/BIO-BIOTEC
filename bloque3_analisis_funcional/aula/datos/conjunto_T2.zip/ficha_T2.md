# Ficha T2 · Temperatura

**Estudio GEO:** [GSE24484](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE24484) · **Plataforma:** [GPL4566](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GPL4566).

**Condición:** 37°C, 11 min.

**Método de selección:** log2((media intensidad t+1)/(media intensidad t0+1)) de 3 réplicas por tiempo; medias de valores procesados; filtro max(media)>=20; abs(log2 FC)>=1; no p diferencial.

**Genes en background:** 5023. **Genes seleccionados:** 863 (647 con cambio positivo, 216 negativo).

**Datos:** valores reales de las matrices publicadas en GEO, procesados para esta práctica. El umbral ±1 en escala log₂ equivale a una razón de 2, y se ha establecido como criterio docente **exploratorio**, no como significación de expresión diferencial.

**Precauciones:** no interpretar la magnitud de cambio como valor p; no inferir activación de procesos a partir del enriquecimiento; la normalización de datos y la calidad experimental no han sido reestimadas aquí. Los genes se deduplican por identificador sistemático ORF, representando varias sondas mediante la mediana de sus valores. El background contiene todos los genes elegibles según filtros de la misma condición.

**Herramienta de enriquecimiento:** utilizar listas .txt de IDs sistemáticos y definir explícitamente como background la lista del mismo código.

**Diseño:** se comparan intensidades medias de las tres réplicas en el tiempo indicado y las tres réplicas del tiempo cero. El cálculo es descriptivo y no sustituye un modelo estadístico de expresión diferencial con ajuste de efectos de filtro.
