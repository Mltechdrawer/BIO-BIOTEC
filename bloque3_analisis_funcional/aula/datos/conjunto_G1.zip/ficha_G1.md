# Ficha G1 · Glucosa

**Estudio GEO:** [GSE4158](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE4158) · **Plataforma:** [GPL3415](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GPL3415).

**Condición:** 2 g/L, 20 min.

**Método de selección:** Mediana de log2(Cy5/Cy3) por gen; selección abs(log2 ratio) >= 1; sin p de expresión diferencial.

**Genes en background:** 6212. **Genes seleccionados:** 1111 (486 con cambio positivo, 625 negativo).

**Datos:** valores reales de las matrices publicadas en GEO, procesados para esta práctica. El umbral ±1 en escala log₂ equivale a una razón de 2, y se ha establecido como criterio docente **exploratorio**, no como significación de expresión diferencial.

**Precauciones:** no interpretar la magnitud de cambio como valor p; no inferir activación de procesos a partir del enriquecimiento; la normalización de datos y la calidad experimental no han sido reestimadas aquí. Los genes se deduplican por identificador sistemático ORF, representando varias sondas mediante la mediana de sus valores. El background contiene todos los genes elegibles según filtros de la misma condición.

**Herramienta de enriquecimiento:** utilizar listas .txt de IDs sistemáticos y definir explícitamente como background la lista del mismo código.

**Diseño:** una observación por dosis/tiempo, razón log₂ frente a referencia inicial. No se estima significación diferencial.
